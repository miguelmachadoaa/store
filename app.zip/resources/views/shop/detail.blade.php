<x-front-layout>
    @section('title', $product->meta_title ?: $product->name . ' - ' . config('app.name'))
    @section('meta_description', $product->meta_description ?: Str::limit(strip_tags($product->description), 160))

    {{-- Contenedor del Breadcrumb optimizado para ocultarse en móvil --}}
    <div class="max-w-7xl mx-auto pt-6 px-6 hidden sm:block">
        <x-breadcrumb :items="[
            ['label' => 'Productos', 'url' => route('shop.index')],
            ['label' => $product->category->name ?? 'Sin Categoría', 'url' => $product->category ? route('shop.byCategory', $product->category->slug) : null],
            ['label' => $product->name]
        ]" />
    </div>

    <div class="max-w-7xl mx-auto py-4 px-6 grid grid-cols-1 lg:grid-cols-2 gap-10">

        {{-- Galería de imágenes --}}
        <div>
            {{-- Imagen principal con Zoom --}}
            <div class="relative overflow-hidden rounded-lg shadow cursor-zoom-in group mb-4"
                x-data="{ zoom: false, x: 0, y: 0 }"
                @mousemove="x = ($event.offsetX / $event.target.offsetWidth) * 100; y = ($event.offsetY / $event.target.offsetHeight) * 100"
                @mouseenter="zoom = true" @mouseleave="zoom = false">

                <img id="main-image" src="{{ Storage::disk('r2')->url($product->image) }}"
                    class="w-full h-auto max-h-[400px] object-cover bg-white transition-transform duration-300"
                    :style="zoom ? `transform: scale(2); transform-origin: ${x}% ${y}%` : ''">
            </div>

            {{-- Slider de Miniaturas (Swiper) --}}
            <div class="swiper thumbSwiper">
                <div class="swiper-wrapper">
                    {{-- Imagen principal --}}
                    <div class="swiper-slide cursor-pointer">
                        <img src="{{ Storage::disk('r2')->url($product->image) }}"
                            class="h-24 w-full object-cover rounded border thumb-item active"
                            onclick="changeMainImage('{{ Storage::disk('r2')->url($product->image) }}', this)">
                    </div>

                    {{-- Imágenes adicionales --}}
                    @foreach($product->images as $img)
                        <div class="swiper-slide cursor-pointer">
                            <img src="{{ Storage::disk('r2')->url($img->image) }}"
                                class="h-24 w-full object-cover rounded border thumb-item"
                                onclick="changeMainImage('{{ Storage::disk('r2')->url($img->image) }}', this)">
                        </div>
                    @endforeach
                </div>
                {{-- Navegación --}}
                <div class="swiper-button-next !text-pink-600 !w-6 !h-6 after:text-sm"></div>
                <div class="swiper-button-prev !text-pink-600 !w-6 !h-6 after:text-sm"></div>
            </div>
        </div>

        {{-- Información del producto --}}
        <div>
            @php
                $showUsd = $storeSettings->showUsd();
                $showBs = $storeSettings->showBs();
            @endphp

            {{-- Marca --}}
            @if($product->brand)
                <a href="{{ route('shop.byBrand', $product->brand->slug) }}"
                    class="text-sm text-pink-600 font-semibold hover:underline">
                    {{ $product->brand->name }}
                </a>
            @endif

            {{-- Título --}}
            <h1 class="text-3xl font-bold text-gray-900 mb-2">{{ $product->name }}</h1>

            {{-- Valoración Promedio --}}
            <div class="flex items-center gap-2 mb-4">
                <div class="flex text-yellow-400">
                    @for($i = 1; $i <= 5; $i++)
                        @if($i <= floor($product->average_rating))
                            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                        @elseif($i - $product->average_rating < 1)
                            <svg class="w-5 h-5 fill-current opacity-50" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                        @else
                            <svg class="w-5 h-5 text-gray-300 fill-current" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                        @endif
                    @endfor
                </div>
                <span class="text-sm font-medium text-gray-500">({{ $product->approvedReviews->count() }} reseñas)</span>
            </div>

            {{-- Categoría --}}
            @if($product->category)
                <p class="text-gray-500 text-sm mt-1">
                    Categoría:
                    <a href="{{ route('shop.index', ['category' => $product->category_id]) }}"
                        class="text-pink-600 hover:underline">
                        {{ $product->category->name }}
                    </a>
                </p>
            @endif

            {{-- Componente Reactivo de Producto con Paquetes y Selección de Cantidad --}}
<div x-data="{ 
    quantity: 1,
    unitPrice: {{ $product->price }},
    unitPriceBs: {{ $product->price_bs }},
    bundles: [
        { qty: 1, price: {{ $product->price }}, discountLabel: '', freeShipping: false },
        { qty: 2, price: {{ $product->price * 2 * 0.95 }}, discountLabel: '5% Desc.', freeShipping: false },
        { qty: 3, price: {{ $product->price * 3 * 0.88 }}, discountLabel: 'Mejor Opción + ENVÍO GRATIS', freeShipping: true }
    ],
    selectedBundle: 1,
    
    // Método para calcular el precio dinámico
    getTotalPrice() {
        let bundle = this.bundles.find(b => b.qty === this.quantity);
        return bundle ? bundle.price : (this.quantity * this.unitPrice);
    },
    
    selectBundle(qty) {
        this.quantity = qty;
        this.selectedBundle = qty;
    }
}">

    {{-- Precio Dinámico --}}
    <div class="mt-4">
        <div class="flex flex-col items-start gap-1">
            @if($showUsd)
                <p class="text-4xl font-bold text-gray-900">
                    $<span x-text="getTotalPrice().toFixed(2)"></span>
                </p>
            @endif

            @if($showBs)
                <p class="text-2xl font-semibold text-gray-600">
                    Bs. <span x-text="(getTotalPrice() * (unitPriceBs / unitPrice)).toFixed(2)"></span>
                </p>
            @endif
        </div>

        @if($product->compare_price)
            <p class="text-gray-500 line-through mt-2">
                @if($showUsd)
                    ${{ number_format($product->compare_price, 2) }}
                @endif
                @if($showUsd && $showBs) / @endif
                @if($showBs)
                    Bs. {{ number_format($product->compare_price_bs, 2) }}
                @endif
            </p>
        @endif
    </div>

    {{-- Stock --}}
    <p class="mt-2 text-sm {{ $product->stock > 0 ? 'text-green-600' : 'text-red-600' }}">
        {{ $product->stock > 0 ? 'En stock' : 'Agotado' }}
    </p>

    {{-- Selector de Ofertas por Paquete (Bundles) --}}
    @if($product->stock > 0)
        <div class="mt-5 space-y-2.5">
            <h3 class="text-sm font-bold text-gray-800 uppercase tracking-wide">¿Cuántas quieres llevar?</h3>
            
            <div class="grid grid-cols-1 gap-2.5">
                {{-- Paquete 1 --}}
                <label @click="selectBundle(1)" 
                    :class="selectedBundle === 1 ? 'border-pink-600 bg-pink-50/40 ring-1 ring-pink-600' : 'border-gray-200 hover:border-gray-300 bg-white'"
                    class="relative flex items-center justify-between p-3.5 border rounded-xl cursor-pointer transition-all duration-200">
                    <div class="flex items-center gap-3">
                        <input type="radio" name="bundle_selection" value="1" x-model="selectedBundle" class="text-pink-600 focus:ring-pink-500 h-4 w-4">
                        <div>
                            <span class="font-bold text-gray-900 text-sm">1 Unidad</span>
                        </div>
                    </div>
                    <span class="font-bold text-gray-900 text-sm">${{ number_format($product->price, 2) }}</span>
                </label>

                {{-- Paquete 2 --}}
                <label @click="selectBundle(2)" 
                    :class="selectedBundle === 2 ? 'border-pink-600 bg-pink-50/40 ring-1 ring-pink-600' : 'border-gray-200 hover:border-gray-300 bg-white'"
                    class="relative flex items-center justify-between p-3.5 border rounded-xl cursor-pointer transition-all duration-200">
                    <div class="flex items-center gap-3">
                        <input type="radio" name="bundle_selection" value="2" x-model="selectedBundle" class="text-pink-600 focus:ring-pink-500 h-4 w-4">
                        <div>
                            <span class="font-bold text-gray-900 text-sm">2 Unidades</span>
                            <span class="ml-2 text-xs bg-purple-100 text-purple-700 font-semibold px-2 py-0.5 rounded-full">5% DESC</span>
                        </div>
                    </div>
                    <span class="font-bold text-gray-900 text-sm">${{ number_format($product->price * 2 * 0.95, 2) }}</span>
                </label>

                {{-- Paquete 3 (Destacado - Mejor Valor) --}}
                <label @click="selectBundle(3)" 
                    :class="selectedBundle === 3 ? 'border-pink-600 bg-pink-50/60 ring-2 ring-pink-600 shadow-sm' : 'border-pink-300 hover:border-pink-400 bg-white'"
                    class="relative flex items-center justify-between p-3.5 border rounded-xl cursor-pointer transition-all duration-200">
                    <div class="absolute -top-2.5 right-4 bg-pink-600 text-white text-[0.65rem] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-xs">
                        🔥 Más Popular
                    </div>
                    <div class="flex items-center gap-3">
                        <input type="radio" name="bundle_selection" value="3" x-model="selectedBundle" class="text-pink-600 focus:ring-pink-500 h-4 w-4">
                        <div>
                            <span class="font-bold text-gray-900 text-sm">3 Unidades</span>
                            <div class="mt-0.5">
                                <span class="text-xs bg-green-100 text-green-700 font-bold px-2 py-0.5 rounded-full">🚚 ENVÍO GRATIS</span>
                            </div>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="font-bold text-pink-600 text-base">${{ number_format($product->price * 3 * 0.88, 2) }}</span>
                    </div>
                </label>
            </div>

            {{-- Selector de Cantidad Manual (- 1 +) para cantidades personalizadas --}}
            <div class="flex items-center gap-3 pt-2">
                <span class="text-xs font-semibold text-gray-600">O elige otra cantidad:</span>
                <div class="flex items-center border border-gray-300 rounded-lg overflow-hidden bg-white">
                    <button type="button" @click="if (quantity > 1) { quantity--; selectedBundle = quantity; }" class="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-sm transition">-</button>
                    <span class="px-4 py-1 text-sm font-bold text-gray-900" x-text="quantity"></span>
                    <button type="button" @click="quantity++; selectedBundle = quantity;" class="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-sm transition">+</button>
                </div>
            </div>
        </div>
    @endif

    {{-- Botones de Acción integrados con la cantidad seleccionada --}}
    <div class="mt-6 flex flex-col gap-3 w-full">
        
        <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full">
            
            {{-- 2. Botón Comprar Ya --}}
            @if($product->stock > 0)
                <div class="flex-1 min-w-0">
                    <form action="{{ route('cart.buy-now', $product->id) }}" method="POST" class="m-0 p-0">
                        @csrf
                        {{-- Input oculto que envía la cantidad seleccionada --}}
                        <input type="hidden" name="quantity" :value="quantity">
                        
                        <button type="submit" 
                            class="w-full bg-[#db2777] hover:bg-[#be185d] text-white border-none font-medium text-[0.75rem] uppercase tracking-[0.08em] cursor-pointer flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 shadow-sm"
                            style="border-radius: 2rem; padding: 0.6rem 1rem; font-family: 'DM Sans', sans-serif; height: 42px;">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0">
                                <path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                            </svg>
                            <span class="truncate">Comprar ya</span>
                        </button>
                    </form>
                </div>
            @endif

            {{-- 1. Botón Agregar al Carrito --}}
            <div class="flex-1 min-w-0">
                <x-add-to-cart-button :product="$product" />
            </div>
        </div>

        {{-- 3. Botón de WhatsApp dinámico según la cantidad seleccionada --}}
        @if($product->stock > 0)
            @php $phone = "584245478154"; @endphp
            <div class="w-full">
                <a :href="'https://wa.me/{{ $phone }}?text=' + encodeURIComponent('¡Hola! Me interesa comprar ' + quantity + ' unidad(es) del producto: *{{ $product->name }}* por un total de $' + getTotalPrice().toFixed(2) + '. ¿Tienen disponibilidad?')" 
                    target="_blank"
                    class="w-full text-white font-bold text-[0.8rem] uppercase tracking-[0.08em] flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 shadow-md no-underline" 
                    style="background-color: #25D366 !important; border-radius: 2rem; padding: 0.7rem 1rem; font-family: 'DM Sans', sans-serif; height: 44px;">
                    <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24">
                        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397 0 11.973 0c3.184.001 6.177 1.242 8.426 3.496 2.248 2.253 3.487 5.244 3.484 8.425-.004 6.625-5.34 11.973-11.916 11.973-1.994-.001-3.953-.5-5.69-1.446L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.794 1.451 5.435 0 9.856-4.42 9.86-9.858.002-2.634-1.023-5.11-2.881-6.97C16.502 1.868 14.032.843 11.397.842 5.96.842 1.54 5.261 1.537 10.7c-.001 1.713.453 3.39 1.313 4.873L1.86 21.082l5.723-1.5-.936.572z"/>
                    </svg>
                    <span> Consultar o pedir por WhatsApp</span>
                </a>
            </div>
        @endif

    </div>

</div>

            {{-- Sección de Confianza, Garantía e Información de Envíos --}}
            <div class="mt-6 space-y-3">
                
                {{-- Bloque Destacado de Envíos --}}
                <div class="p-4 bg-gradient-to-r from-pink-50/70 to-purple-50/70 border border-pink-100 rounded-xl shadow-xs">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="text-xl">🚚</span>
                        <h4 class="font-bold text-gray-900 text-sm sm:text-base">Información de Envíos y Entregas</h4>
                    </div>

                    <ul class="space-y-2 text-xs sm:text-sm text-gray-700">
                        <li class="flex items-start gap-2">
                            <span class="font-bold text-pink-600">📦 Nacionales:</span>
                            <span>Tarifa desde <strong>2.400 Bs</strong> vía <strong>MRW</strong>. También enviamos cobro en destino por <strong>Zoom</strong> y <strong>Tealca</strong>.</span>
                        </li>
                       
                        <li class="flex items-start gap-2">
                            <span class="font-bold text-pink-600">📍 Maracay:</span>
                            <span>Contamos con <strong>entregas personales</strong> en la ciudad.</span>
                        </li>

                         <li class="flex items-start gap-2">
                            <span class="font-bold text-pink-600">🎉 Envío GRATIS:</span>
                            <span>Aplica en compras superiores a <strong>$30 USD</strong> a nivel nacional.</span>
                        </li>


                        <li class="flex items-start gap-2">
                            <span class="font-bold text-pink-600">⏱️ Tiempo estimado:</span>
                            <span>Despacho rápido en 1 a 2 días hábiles.</span>
                        </li>
                    </ul>
                </div>

                {{-- Beneficios de Compra --}}
                <div class="p-4 bg-gray-50 border border-gray-100 rounded-xl space-y-2.5">
                    <div class="flex items-center gap-3 text-xs sm:text-sm text-gray-600">
                        <svg class="w-4 h-4 text-pink-600 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                        </svg>
                        <span><strong>Pago 100% Seguro:</strong> Cifrado de datos y métodos locales protegidos.</span>
                    </div>
                    <div class="flex items-center gap-3 text-xs sm:text-sm text-gray-600">
                        <svg class="w-4 h-4 text-pink-600 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M14 10h4.757a1 1 0 01.707 1.707l-5.414 5.414a1 1 0 01-.707.293H10.5a1 1 0 01-.707-.293l-5.414-5.414A1 1 0 015.086 10H10V4a1 1 0 011-1h2a1 1 0 011 1v6z"/>
                        </svg>
                        <span><strong>Compra Garantizada:</strong> Atención personalizada post-venta.</span>
                    </div>
                </div>

            </div>

            {{-- Descripción --}}
            <div class="mt-8">
                <h3 class="text-xl font-semibold mb-2">Descripción</h3>
                <p class="text-gray-700 leading-relaxed">
                    {!! nl2br(e($product->description)) !!}
                </p>
            </div>


        </div>
    </div>

    {{-- Sección de Piedras Naturales y Propiedades --}}
@if($product->stones && $product->stones->count() > 0)
    <div class="mt-10 border-t pt-8">
        <div class="bg-gradient-to-br from-pink-50/50 via-purple-50/30 to-white p-5 sm:p-8 rounded-2xl border border-pink-100 shadow-sm">
            
            {{-- Encabezado de la sección --}}
            <div class="flex items-center gap-3 mb-6">
                <div class="p-2.5 bg-pink-100 text-pink-600 rounded-xl flex-shrink-0">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                    </svg>
                </div>
                <div>
                    <h3 class="text-lg sm:text-xl font-bold text-gray-900 tracking-tight">Piedras y Energías Naturales</h3>
                    <p class="text-xs sm:text-sm text-gray-500">Descubre los beneficios energéticos de los minerales en esta pieza</p>
                </div>
            </div>

            {{-- Grid Responsivo Mobile-First --}}
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                @foreach($product->stones as $stone)
                    <div class="bg-white p-4 sm:p-5 rounded-xl border border-gray-100 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between">
                        <div>
                            {{-- Cabecera de la Tarjeta de Piedra --}}
                            <div class="flex items-center gap-3 mb-3">
                                @if($stone->image)
                                    <img src="{{ Storage::disk('r2')->url($stone->image) }}" 
                                         alt="{{ $stone->name }}" 
                                         class="w-12 h-12 rounded-full object-cover border-2 border-pink-100 flex-shrink-0 shadow-xs">
                                @else
                                    <div class="w-12 h-12 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold text-lg flex-shrink-0">
                                        {{ mb_substr($stone->name, 0, 1) }}
                                    </div>
                                @endif

                                <div>
                                    <h4 class="font-bold text-gray-900 text-base leading-snug">{{ $stone->name }}</h4>
                                    @if(!empty($stone->chakras) && (is_iterable($stone->chakras) ? count($stone->chakras) > 0 : true))
                                        <div class="flex flex-wrap gap-1 mt-1">
                                            @if(is_iterable($stone->chakras))
                                                {{-- Si es una colección de Eloquent o un array --}}
                                                @foreach($stone->chakras as $chakra)
                                                    <span class="inline-block text-[0.7rem] bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full font-medium">
                                                        Chakra: {{ is_object($chakra) ? $chakra->name : $chakra }}
                                                    </span>
                                                @endforeach
                                            @else
                                                {{-- Fallback si eventualmente viene como string --}}
                                                <span class="inline-block text-[0.7rem] bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full font-medium">
                                                    Chakra: {{ $stone->chakras }}
                                                </span>
                                            @endif
                                        </div>
                                    @endif
                                </div>
                            </div>

                            {{-- Descripción / Beneficios --}}
                            <p class="text-xs sm:text-sm text-gray-600 leading-relaxed">
                                @php
                                    $benefitText = $stone->subtitle ?? $stone->description;
                                @endphp

                                @if(is_array($benefitText))
                                    {{ implode(', ', $benefitText) }}
                                @else
                                    {{ $benefitText }}
                                @endif
                            </p>
                        </div>

                        {{-- Propiedades secundarias / Tags (Opcional) --}}
                        @if(!empty($stone->benefits))
                            <div class="mt-4 pt-3 border-t border-gray-100 flex flex-wrap gap-1.5">
                                @foreach(is_array($stone->benefits) ? $stone->benefits : explode(',', $stone->benefits) as $benefit)
                                    <span class="text-[0.68rem] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-md font-medium">
                                        ✨ {{ trim($benefit) }}
                                    </span>
                                @endforeach
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>

        </div>
    </div>
@endif

    {{-- Productos relacionados --}}
    <div class="max-w-7xl mx-auto px-6 mt-12">
        <h2 class="text-2xl font-bold mb-6">Productos relacionados</h2>

        @if($related->count())
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($related as $item)
                    <x-product-card :product="$item" />
                @endforeach
            </div>
        @else
            <p class="text-gray-500">No hay productos relacionados.</p>
        @endif
    </div>

    {{-- Sección de Reseñas --}}
    <div class="mt-16 border-t pt-10" x-data="{ activeModalImage: null }">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12 max-w-7xl mx-auto px-6">
            {{-- Resumen y Formulario --}}
            <div class="lg:col-span-1">
                <h2 class="text-2xl font-bold text-gray-900 mb-4">Reseñas de Clientes</h2>
                
                <div class="flex items-center gap-4 mb-6">
                    <span class="text-5xl font-bold text-gray-900">{{ $product->average_rating }}</span>
                    <div>
                        <div class="flex text-yellow-400">
                            @for($i = 1; $i <= 5; $i++)
                                <svg class="w-5 h-5 {{ $i <= floor($product->average_rating) ? 'fill-current' : 'text-gray-300 fill-current' }}" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                            @endfor
                        </div>
                        <p class="text-sm text-gray-500 mt-1">Basado en {{ $product->approvedReviews->count() }} opiniones</p>
                    </div>
                </div>

                @auth
                    @php $userReview = $product->reviews()->where('user_id', auth()->id())->first();
                    
                    @endphp
                    
                    @if(!$userReview)
                        <div class="bg-gray-50 p-6 rounded-lg border">
                            <h3 class="font-bold text-gray-900 mb-4">Escribe una reseña</h3>
                            <form action="{{ route('products.reviews.store', $product->id) }}" method="POST" enctype="multipart/form-data" class="space-y-4">
                                @csrf
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Tu Valoración</label>
                                    <div class="flex gap-2" x-data="{ rating: 5 }">
                                        @for($i = 1; $i <= 5; $i++)
                                            <button type="button" @click="rating = {{ $i }}" class="focus:outline-none">
                                                <svg class="w-8 h-8 transition-colors" :class="rating >= {{ $i }} ? 'text-yellow-400 fill-current' : 'text-gray-300 fill-current'" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                                            </button>
                                        @endfor
                                        <input type="hidden" name="rating" :value="rating">
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Tu Comentario</label>
                                    <textarea name="comment" rows="3" required
                                        class="w-full border-gray-300 focus:border-pink-500 focus:ring-pink-500 rounded-lg shadow-sm text-sm"
                                        placeholder="¿Qué te pareció el producto?"></textarea>
                                </div>

                                {{-- Input para Foto de Reseña --}}
                                <div x-data="{ imagePreview: null }">
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Foto del producto (Opcional)</label>
                                    <input type="file" name="image" accept="image/*" 
                                        @change="const file = $event.target.files[0]; if (file) { const reader = new FileReader(); reader.onload = (e) => imagePreview = e.target.result; reader.readAsDataURL(file); }"
                                        class="w-full text-xs text-gray-500 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-pink-50 file:text-pink-700 hover:file:bg-pink-100 cursor-pointer">
                                    
                                    {{-- Vista previa de la imagen cargada --}}
                                    <template x-if="imagePreview">
                                        <div class="mt-2 relative inline-block">
                                            <img :src="imagePreview" class="h-20 w-20 object-cover rounded-lg border border-gray-200 shadow-sm">
                                            <button type="button" @click="imagePreview = null; $el.closest('div').querySelector('input[type=file]').value = ''" 
                                                class="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow hover:bg-red-600 transition">
                                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                                            </button>
                                        </div>
                                    </template>
                                </div>

                                <button type="submit" class="w-full bg-pink-600 text-white py-2 rounded-lg font-bold hover:bg-pink-700 transition text-sm">
                                    Enviar Reseña
                                </button>
                                <p class="text-xs text-gray-500 text-center italic">Su reseña será moderada antes de publicarse.</p>
                            </form>
                        </div>
                    @else
                        <div class="bg-blue-50 p-4 rounded-lg border border-blue-100 text-blue-800 text-sm">
                            Ya has enviado una reseña para este producto. Gracias por tu opinión.
                        </div>
                    @endif
                @else
                    <div class="bg-gray-50 p-6 rounded-lg border text-center">
                        <p class="text-gray-600 mb-4 text-sm">Debes iniciar sesión para dejar una reseña.</p>
                        <a href="{{ route('login') }}" class="inline-block bg-gray-900 text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800 transition text-sm">
                            Iniciar Sesión
                        </a>
                    </div>
                @endauth
            </div>

            {{-- Listado de Reseñas --}}
            <div class="lg:col-span-2">
                <div class="space-y-8">
                    @forelse($product->approvedReviews()->latest()->get() as $review)
                        <div class="border-b pb-8">
                            <div class="flex items-center justify-between mb-2">
                                <div class="flex items-center gap-3">
                                    <span class="font-bold text-gray-900">{{ $review->user->name }}</span>
                                    @if($product->hasUserPurchased($review->user))
                                        <span class="inline-flex items-center gap-1 bg-green-100 text-green-700 text-xs font-bold px-2 py-0.5 rounded-full">
                                            <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                                            Compra Verificada
                                        </span>
                                    @endif
                                </div>
                                <span class="text-sm text-gray-500">{{ $review->created_at->format('d M, Y') }}</span>
                            </div>
                            <div class="flex text-yellow-400 mb-3">
                                @for($i = 1; $i <= 5; $i++)
                                    <svg class="w-4 h-4 {{ $i <= $review->rating ? 'fill-current' : 'text-gray-300 fill-current' }}" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                                @endfor
                            </div>
                            
                            <p class="text-gray-600 leading-relaxed text-sm">{{ $review->comment }}</p>

                            {{-- Foto adjunta de la reseña --}}
                            @php
                                $firstImagePath = $review->images->first()?->image_path;
                            @endphp

                            @if($firstImagePath)
                                <div class="mt-4">
                                    <img src="{{ Storage::disk('r2')->url($firstImagePath) }}" 
                                        alt="Foto de {{ $review->user->name }}"
                                        @click="activeModalImage = '{{ Storage::disk('r2')->url($firstImagePath) }}'"
                                        class="h-24 w-24 object-cover rounded-lg border border-gray-200 cursor-pointer hover:opacity-90 transition shadow-sm">
                                </div>
                            @endif
                        </div>
                    @empty
                        <div class="text-center py-10 bg-gray-50 rounded-lg">
                            <p class="text-gray-500 text-sm">No hay reseñas aprobadas todavía. ¡Sé el primero en opinar!</p>
                        </div>
                    @endforelse
                </div>
            </div>
        </div>

        {{-- Modal Lightbox para ampliar la imagen de la reseña --}}
        <template x-if="activeModalImage">
            <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" @click.self="activeModalImage = null">
                <div class="relative max-w-3xl max-h-[90vh]">
                    <img :src="activeModalImage" class="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl">
                    <button @click="activeModalImage = null" class="absolute -top-4 -right-4 bg-white text-gray-900 rounded-full p-2 shadow-lg hover:bg-gray-100 transition">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                </div>
            </div>
        </template>
    </div>

    <style>
        .thumb-item.active {
            border-color: #db2777; /* pink-600 */
            border-width: 2px;
        }
    </style>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            // Inicializar Swiper para miniaturas
            new Swiper(".thumbSwiper", {
                slidesPerView: 4,
                spaceBetween: 10,
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                breakpoints: {
                    640: { slidesPerView: 4 },
                    1024: { slidesPerView: 5 },
                }
            });
        });

        function changeMainImage(src, el) {
            // Cambiar imagen principal
            document.getElementById('main-image').src = src;

            // Actualizar clase activa
            document.querySelectorAll('.thumb-item').forEach(img => {
                img.classList.remove('active');
            });
            el.classList.add('active');
        }

        function toggleWishlist(productId, button) {
            fetch(`/wishlist/toggle/${productId}`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const textSpan = button.querySelector('.wishlist-text');
                    
                    if (data.favorited) {
                        button.classList.remove('text-gray-400');
                        button.classList.add('text-pink-600');
                        if (textSpan) textSpan.textContent = 'Quitar de Favoritos';
                    } else {
                        button.classList.remove('text-pink-600');
                        button.classList.add('text-gray-400');
                        if (textSpan) textSpan.textContent = 'Guardar en Favoritos';
                    }
                }
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
</x-front-layout>