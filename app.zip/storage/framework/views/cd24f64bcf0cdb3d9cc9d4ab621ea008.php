<section class="zolum-news-section">
    <div class="zolum-container">

        
        <div class="zolum-news-header">
            <div>
                <h2 class="zolum-news-title">
                    Tendencias & Estilo de Vida
                </h2>
                <p class="zolum-news-subtitle">
                    Tu estilo de vida, evolucionado.
                </p>
            </div>

            <a href="<?php echo e(route('blog.index')); ?>" class="zolum-news-link">
                Ver todo <span class="zolum-arrow">→</span>
            </a>
        </div>

        
        <div class="zolum-news-grid">

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="zolum-post-card">

                    
                    <?php if($post->image): ?>
                        <div class="zolum-card-image-wrapper">
                            <img src="<?php echo e(asset('storage/' . $post->image)); ?>" 
                                 alt="<?php echo e($post->title); ?>" 
                                 class="zolum-card-image">
                        </div>
                    <?php else: ?>
                        
                        <div class="zolum-card-placeholder">
                            <span class="zolum-placeholder-text">ZOLUM SHOP</span>
                        </div>
                    <?php endif; ?>

                    
                    <div class="zolum-card-body">
                        
                        <h3 class="zolum-card-title">
                            <?php echo e($post->title); ?>

                        </h3>

                        <p class="zolum-card-excerpt">
                            <?php echo e($post->excerpt); ?>

                        </p>

                        
                        <div class="zolum-card-footer">
                            <span class="zolum-card-date">
                                <?php echo e($post->created_at->format('d M, Y')); ?>

                            </span>
                            <span class="zolum-card-more">Leer artículo</span>
                        </div>
                    </div>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section><?php /**PATH C:\laragon\www\store\resources\views/components/latest-news.blade.php ENDPATH**/ ?>