<?php if (isset($component)) { $__componentOriginal9d41032d5dde91ab243771384dacb5df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d41032d5dde91ab243771384dacb5df = $attributes; } ?>
<?php $component = App\View\Components\FrontLayout::resolve(['sliders' => $sliders,'brands' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<style>
    .categories-swiper {
        width: 100%;
        padding: 10px 0;
    }

    /* Estilización y reubicación de las flechas de Swiper */
    .cat-swiper-btn-prev,
    .cat-swiper-btn-next {
        color: var(--warm-orange, #FFC933) !important; /* Tu color de acento */
        background-color: #FFFFFF;
        width: 40px !important;
        height: 40px !important;
        border-radius: 50%;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        top: 60% !important; /* Centrado vertical con respecto a las tarjetas */
        transition: all 0.2s ease;
    }

    /* Reducir el tamaño de la flecha interna de Swiper */
    .cat-swiper-btn-prev::after,
    .cat-swiper-btn-next::after {
        font-size: 16px !important;
        font-weight: bold;
    }

    .cat-swiper-btn-prev:hover,
    .cat-swiper-btn-next:hover {
        background-color: var(--warm-orange, #FFC933);
        color: #FFFFFF !important;
        transform: scale(1.05);
    }

    /* Posicionamiento exacto en los extremos del contenedor interior */
    .cat-swiper-btn-prev { left: 0px !important; }
    .cat-swiper-btn-next { right: 0px !important; }

    /* Ocultar flechas si están deshabilitadas (ej. pocos elementos) */
    .swiper-button-disabled {
        opacity: 0 !important;
        pointer-events: none;
    }
</style>


<div class="trust-bar">
    <div class="trust-bar__inner">
        <?php $__currentLoopData = [
            ['icon' => '💬', 'title' => 'Soporte 24/7',        'sub' => 'Siempre disponibles para ti'],
            ['icon' => '🚚', 'title' => 'Envío gratuito',       'sub' => 'En pedidos desde $30'],
            ['icon' => '🔒', 'title' => 'Pago seguro',          'sub' => 'Cifrado SSL garantizado'],
            ['icon' => '✨', 'title' => 'Garantía de energía',  'sub' => 'Piedras certificadas'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="trust-item">
                <div class="trust-item__icon"><?php echo e($trust['icon']); ?></div>
                <div class="trust-item__text">
                    <strong><?php echo e($trust['title']); ?></strong>
                    <?php echo e($trust['sub']); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<?php if(isset($categories) && $categories->count() > 0): ?>
<section class="cat-section">
    <div class="cat-section__inner" style="position: relative; padding: 0 40px;"> 
        

        
        <div class="swiper categories-swiper">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <a href="<?php echo e(route('shop.byCategory', $category->slug)); ?>" class="cat-card" style="margin: 0; width: 100%;">
                            <div class="cat-card__img">
                                <?php if($category->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>">
                                <?php else: ?>
                                    <div class="cat-card__placeholder">🔮</div>
                                <?php endif; ?>
                            </div>
                            <div class="cat-card__label">
                                <?php echo e($category->name); ?>

                                <span>→</span>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="swiper-button-prev cat-swiper-btn-prev"></div>
        <div class="swiper-button-next cat-swiper-btn-next"></div>

    </div>
</section>





<?php endif; ?>

<section class="products-section">
    <div class="products-section__inner">
        <div class="deal-banner">
            <div class="deal-banner__text">
                <p class="eyebrow">Oferta especial · Esta semana</p>
                <h2>Descuentos de hasta <em>50% off</em></h2>
            </div>
            <a href="<?php echo e(route('shop.index')); ?>" class="deal-banner__cta">Ver todas las ofertas →</a>
        </div>

        <div class="products-grid-4">
            <?php $__currentLoopData = $weeklyDeals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="products-section products-section--alt">
    <div class="products-section__inner">
        <p class="section-eyebrow">Recién llegados</p>
        <h2 class="section-title">Repuestos  <em>originales</em> para tu moto</h2>

        <div class="products-grid-3">
            <?php $__currentLoopData = $recentProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="section-cta-wrap">
            <a href="<?php echo e(route('shop.index')); ?>" class="section-cta">Ver toda la tienda →</a>
        </div>
    </div>
</section>

    <?php $__currentLoopData = $categoriesFeature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginalb81857d214cd2768126444e73b8a9f3e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb81857d214cd2768126444e73b8a9f3e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.category-feature','data' => ['category' => $category]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('category-feature'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb81857d214cd2768126444e73b8a9f3e)): ?>
<?php $attributes = $__attributesOriginalb81857d214cd2768126444e73b8a9f3e; ?>
<?php unset($__attributesOriginalb81857d214cd2768126444e73b8a9f3e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb81857d214cd2768126444e73b8a9f3e)): ?>
<?php $component = $__componentOriginalb81857d214cd2768126444e73b8a9f3e; ?>
<?php unset($__componentOriginalb81857d214cd2768126444e73b8a9f3e); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<section class="newsletter-section">
    <div class="newsletter-inner">
        <p class="newsletter-eyebrow">Comunidad de entusiastas</p>
        <h2 class="newsletter-title">Únete a nuestra <em>comunidad </em></h2>
        <p class="newsletter-sub">
            Recibe actualizaciones sobre nuevos productos, ofertas especiales y contenido exclusivo.
        </p>

        <form action="<?php echo e(route('newsletter.store')); ?>" method="POST" class="newsletter-form">
            <?php echo csrf_field(); ?>
            <input type="email" name="email" class="newsletter-input"
                   placeholder="tucorreo@ejemplo.com" required>
            <button type="submit" class="newsletter-btn">Suscribirme</button>
        </form>

        <?php if(session('success')): ?>
            <p class="newsletter-success">✦ <?php echo e(session('success')); ?></p>
        <?php endif; ?>
    </div>
</section>

<?php if (isset($component)) { $__componentOriginal6a9c4082cac7a4d6ed35175588d4bfc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a9c4082cac7a4d6ed35175588d4bfc3 = $attributes; } ?>
<?php $component = App\View\Components\LatestNews::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('latest-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LatestNews::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a9c4082cac7a4d6ed35175588d4bfc3)): ?>
<?php $attributes = $__attributesOriginal6a9c4082cac7a4d6ed35175588d4bfc3; ?>
<?php unset($__attributesOriginal6a9c4082cac7a4d6ed35175588d4bfc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a9c4082cac7a4d6ed35175588d4bfc3)): ?>
<?php $component = $__componentOriginal6a9c4082cac7a4d6ed35175588d4bfc3; ?>
<?php unset($__componentOriginal6a9c4082cac7a4d6ed35175588d4bfc3); ?>
<?php endif; ?>

<div class="promo-strip">
    <h2>Encuentra tu <em>repuesto</em> perfecto</h2>
    <p>Cada pieza lleva consigo años de calidad y durabilidad</p>
    <a href="<?php echo e(route('shop.index')); ?>">Explorar colección</a>
</div>



<script>
    document.addEventListener('DOMContentLoaded', function () {
        new Swiper('.categories-swiper', {
            slidesPerView: 1,
            spaceBetween: 16,
            grabCursor: true,
            // Configuración de flechas
            navigation: {
                nextEl: '.cat-swiper-btn-next',
                prevEl: '.cat-swiper-btn-prev',
            },
            // Puntos de quiebre responsivos (Breakpoints)
            breakpoints: {
                480: {
                    slidesPerView: 2,
                    spaceBetween: 16
                },
                768: {
                    slidesPerView: 3,
                    spaceBetween: 20
                },
                1024: {
                    slidesPerView: 4,
                    spaceBetween: 24
                },
                1280: {
                    slidesPerView: 6, 
                    spaceBetween: 24
                }
            }
        });
    });
</script>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $attributes = $__attributesOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__attributesOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $component = $__componentOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__componentOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\store\resources\views/home.blade.php ENDPATH**/ ?>