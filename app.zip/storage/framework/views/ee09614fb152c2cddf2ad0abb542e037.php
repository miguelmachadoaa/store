<div class="relative w-full overflow-hidden">

    <div class="swiper mySwiper">
        <div class="swiper-wrapper">

            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <div class="relative">

                        
                        <img src="<?php echo e(Storage::disk('r2')->url($slider->image)); ?>"
                             class="w-full h-[450px] object-cover rounded-lg shadow">

                        
                        <div class="absolute top-1/2 left-10 transform -translate-y-1/2 text-white max-w-lg">
                            <h2 class="text-4xl font-bold drop-shadow-lg"><?php echo e($slider->title); ?></h2>

                            <?php if($slider->subtitle): ?>
                                <p class="mt-2 text-lg drop-shadow"><?php echo e($slider->subtitle); ?></p>
                            <?php endif; ?>

                            <?php if($slider->button_text): ?>
                                <a href="<?php echo e($slider->button_link); ?>"
                                   class="mt-4 inline-block bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded shadow">
                                    <?php echo e($slider->button_text); ?>

                                </a>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

        
        <div class="swiper-pagination"></div>
    </div>

</div><?php /**PATH C:\laragon\www\store\resources\views/components/slider.blade.php ENDPATH**/ ?>