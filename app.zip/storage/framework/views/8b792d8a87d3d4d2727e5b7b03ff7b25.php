
<div class="category-view-wrapper" style="display: flex; flex-direction: column; gap: 40px; margin-bottom: 40px;">

    <section class="products-section products-section--alt" style="padding-top: 10px;">
        <div class="products-section__inner">
            <p class="section-eyebrow">Catálogo Disponible</p>
            <h2 class="section-title">Explora nuestra selección de <em><?php echo e($category->name); ?></em></h2>
            

            <?php if($category->children && $category->children->count() > 0): ?>

                <div class="cat-grid mb-4" >
                    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('shop.byCategory', $subcategory->slug)); ?>" class="cat-card">
                            <div class="cat-card__img">
                                <?php if($subcategory->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $subcategory->image)); ?>" alt="<?php echo e($subcategory->name); ?>">
                                <?php else: ?>
                                    
                                    <div class="cat-card__placeholder">🛠️</div>
                                <?php endif; ?>
                            </div>
                            <div class="cat-card__label">
                                <?php echo e($subcategory->name); ?>

                                <span>→</span>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>


            <?php if($category->products && $category->products->count() > 0): ?>
                
                <div class="products-grid-4 mt-4">
                    <?php $__currentLoopData = $category->products->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                
                <div class="ap-catalog__empty" style="margin-top: 20px;">
                    <div class="ap-catalog__empty-icon">📦</div>
                    <h3 class="ap-catalog__empty-title">Sin productos</h3>
                    <p class="ap-catalog__empty-text">Pronto añadiremos nuevos artículos a la sección de <?php echo e($category->name); ?>.</p>
                </div>
            <?php endif; ?>

            
        </div>
    </section>

</div><?php /**PATH C:\laragon\www\store\resources\views/components/category-feature.blade.php ENDPATH**/ ?>