<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Reportes de Pago</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Buscador -->
            <div class="bg-white shadow-sm sm:rounded-xl border border-gray-200 p-6 mb-6">
                <form action="<?php echo e(route('admin.payments.index')); ?>" method="GET" class="flex gap-4">
                    <div class="flex-1">
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                            placeholder="Buscar por referencia, banco o nombre de cliente..."
                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                    </div>
                    <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-md text-sm transition">
                        Buscar
                    </button>
                </form>
            </div>

            <!-- Tabla -->
            <div class="bg-white shadow-lg sm:rounded-xl border border-gray-200 p-6">
                <?php if($reports->count() > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Orden</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cliente</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Banco / Referencia</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Monto (Bs)</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha Pago</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Comprobante</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Acciones</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200 text-sm">
                                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-gray-50 transition">
                                        <td class="px-6 py-4 font-semibold text-indigo-600">
                                            <a href="<?php echo e(route('admin.orders.show', $report->order_id)); ?>">#<?php echo e($report->order_id); ?></a>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="font-medium text-gray-900"><?php echo e($report->order->customer_name); ?></div>
                                            <div class="text-xs text-gray-500"><?php echo e($report->user->email); ?></div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="text-gray-900 font-medium"><?php echo e($report->bank_name); ?></div>
                                            <div class="text-xs text-gray-500">Ref: <?php echo e($report->reference_number); ?></div>
                                        </td>
                                        <td class="px-6 py-4 font-semibold text-gray-900">Bs. <?php echo e(number_format($report->amount_bs, 2)); ?></td>
                                        <td class="px-6 py-4 text-gray-600"><?php echo e(\Carbon\Carbon::parse($report->payment_date)->format('d/m/Y')); ?></td>
                                        <td class="px-6 py-4">
                                            <?php if($report->proof_image): ?>
                                                <a href="<?php echo e(asset('storage/' . $report->proof_image)); ?>" target="_blank" class="text-xs text-indigo-600 hover:underline font-semibold flex items-center gap-1">
                                                    Ver captura ↗
                                                </a>
                                            <?php else: ?>
                                                <span class="text-gray-400 text-xs">Sin captura</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <span class="px-2 py-1 inline-flex text-xs font-semibold rounded-full 
                                                <?php echo e($report->status === 'approved' ? 'bg-green-100 text-green-800' : ($report->status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                                <?php echo e($report->status === 'approved' ? 'Aprobado' : ($report->status === 'rejected' ? 'Rechazado' : 'Pendiente')); ?>

                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-right">
                                            <?php if($report->status === 'pending'): ?>
                                                <div class="flex justify-end gap-2">
                                                    <form action="<?php echo e(route('admin.payments.updateStatus', $report)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="approved">
                                                        <button type="submit" class="bg-green-500 hover:bg-green-600 text-white text-xs px-2 py-1 rounded font-medium transition">Aprobar</button>
                                                    </form>
                                                    <form action="<?php echo e(route('admin.payments.updateStatus', $report)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="rejected">
                                                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white text-xs px-2 py-1 rounded font-medium transition">Rechazar</button>
                                                    </form>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-xs text-gray-400">Procesado</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4"><?php echo e($reports->links()); ?></div>
                <?php else: ?>
                    <p class="text-gray-600 text-center py-4">No hay reportes de pago registrados.</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\store\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>