<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Crear Forma de Pago</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow sm:rounded-lg p-6">
                <form action="<?php echo e(route('admin.payment-methods.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block font-semibold mb-1">Nombre</label>
                            <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                        </div>

                        <div>
                            <label class="block font-semibold mb-1">Tipo de Pago</label>
                            <select name="type" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="manual" <?php echo e(old('type') == 'manual' ? 'selected' : ''); ?>>Manual (Pago Móvil, Zelle, Transferencia)</option>
                                <option value="stripe" <?php echo e(old('type') == 'stripe' ? 'selected' : ''); ?>>Stripe Gateway</option>
                                <option value="paypal" <?php echo e(old('type') == 'paypal' ? 'selected' : ''); ?>>PayPal Gateway</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block font-semibold mb-1">Moneda</label>
                            <select name="currency" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                                <option value="USD" <?php echo e(old('currency') == 'USD' ? 'selected' : ''); ?>>USD ($)</option>
                                <option value="BS" <?php echo e(old('currency') == 'BS' ? 'selected' : ''); ?>>BS (Bs.)</option>
                            </select>
                        </div>

                        <div>
                            <label class="block font-semibold mb-1">Estado</label>
                            <select name="is_active" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="1" <?php echo e(old('is_active', '1') == '1' ? 'selected' : ''); ?>>Activa</option>
                                <option value="0" <?php echo e(old('is_active') == '0' ? 'selected' : ''); ?>>Inactiva</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="block font-semibold mb-1">Instrucciones Adicionales (Opcional)</label>
                        <textarea name="description" rows="3" placeholder="Ej: Reportar la referencia por WhatsApp inmediatamente después de pagar..." class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"><?php echo e(old('description')); ?></textarea>
                    </div>

                    <!-- Archivos Multimedia (Logo + QR) -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 bg-gray-50 rounded-md border border-gray-200">
                        <div>
                            <label class="block font-semibold mb-1 text-sm">Logo / Icono</label>
                            <input type="file" name="logo" accept="image/*" class="w-full text-sm border-gray-300 rounded-md shadow-sm">
                        </div>

                        <div>
                            <label class="block font-semibold mb-1 text-sm">Imagen QR de Pago (Opcional)</label>
                            <input type="file" name="qr_code" accept="image/*" class="w-full text-sm border-gray-300 rounded-md shadow-sm">
                        </div>
                    </div>

                    <!-- Datos Copiables Dinámicos -->
                    <div class="mb-6">
                        <div class="flex justify-between items-center mb-2">
                            <label class="block font-semibold">Datos Bancarios para Copiar</label>
                            <button type="button" id="add-detail-btn" class="px-3 py-1 bg-gray-800 text-white text-xs font-semibold rounded hover:bg-gray-700">
                                + Agregar Campo
                            </button>
                        </div>
                        <p class="text-xs text-gray-500 mb-3">Ingresa los datos formateados (Ej: Banco -> Banesco, Teléfono -> 04141234567) para que el cliente pueda copiarlos en 1 clic.</p>
                        
                        <div id="bank-details-container" class="space-y-2">
                            <!-- Filas predeterminadas -->
                            <div class="flex items-center gap-2 detail-row">
                                <input type="text" name="bank_details[0][label]" value="Banco" placeholder="Ej: Banco" class="w-1/3 rounded-md border-gray-300 text-sm focus:ring-indigo-500">
                                <input type="text" name="bank_details[0][value]" value="" placeholder="Ej: Banesco / Mercantil" class="w-2/3 rounded-md border-gray-300 text-sm focus:ring-indigo-500">
                                <button type="button" class="remove-row text-red-500 hover:text-red-700 font-bold px-2">✕</button>
                            </div>

                            <div class="flex items-center gap-2 detail-row">
                                <input type="text" name="bank_details[1][label]" value="CI / RIF" placeholder="Ej: CI / RIF" class="w-1/3 rounded-md border-gray-300 text-sm focus:ring-indigo-500">
                                <input type="text" name="bank_details[1][value]" value="" placeholder="Ej: V-12345678" class="w-2/3 rounded-md border-gray-300 text-sm focus:ring-indigo-500">
                                <button type="button" class="remove-row text-red-500 hover:text-red-700 font-bold px-2">✕</button>
                            </div>

                            <div class="flex items-center gap-2 detail-row">
                                <input type="text" name="bank_details[2][label]" value="Teléfono" placeholder="Ej: Teléfono" class="w-1/3 rounded-md border-gray-300 text-sm focus:ring-indigo-500">
                                <input type="text" name="bank_details[2][value]" value="" placeholder="Ej: 04141234567" class="w-2/3 rounded-md border-gray-300 text-sm focus:ring-indigo-500">
                                <button type="button" class="remove-row text-red-500 hover:text-red-700 font-bold px-2">✕</button>
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-between items-center mt-6">
                        <a href="<?php echo e(route('admin.payment-methods.index')); ?>" class="text-gray-600 hover:underline">Cancelar</a>
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Script para manejo del JS dinámico -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const container = document.getElementById('bank-details-container');
            const addBtn = document.getElementById('add-detail-btn');
            let rowCount = container.querySelectorAll('.detail-row').length;

            addBtn.addEventListener('click', function () {
                const newRow = document.createElement('div');
                newRow.className = 'flex items-center gap-2 detail-row';
                newRow.innerHTML = `
                    <input type="text" name="bank_details[${rowCount}][label]" placeholder="Ej: Número de Cuenta" class="w-1/3 rounded-md border-gray-300 text-sm focus:ring-indigo-500">
                    <input type="text" name="bank_details[${rowCount}][value]" placeholder="Ej: 0102-0000-00-0000000000" class="w-2/3 rounded-md border-gray-300 text-sm focus:ring-indigo-500">
                    <button type="button" class="remove-row text-red-500 hover:text-red-700 font-bold px-2">✕</button>
                `;
                container.appendChild(newRow);
                rowCount++;
            });

            container.addEventListener('click', function (e) {
                if (e.target && e.target.classList.contains('remove-row')) {
                    const row = e.target.closest('.detail-row');
                    if (container.querySelectorAll('.detail-row').length > 1) {
                        row.remove();
                    }
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\store\resources\views/admin/payment_methods/create.blade.php ENDPATH**/ ?>