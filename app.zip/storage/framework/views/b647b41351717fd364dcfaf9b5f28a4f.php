<?php if (isset($component)) { $__componentOriginal9d41032d5dde91ab243771384dacb5df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d41032d5dde91ab243771384dacb5df = $attributes; } ?>
<?php $component = App\View\Components\FrontLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <style>
        .ap-catalog-grid {
            display: grid;
            /* Fuerza exactamente 4 columnas del mismo tamaño en escritorio */
            grid-template-columns: repeat(4, minmax(0, 1fr)) !important;
            gap: 1.5rem;
        }

        /* Adaptación responsiva para pantallas medianas (Tablets/Laptops pequeñas) */
        @media (max-width: 1200px) {
            .ap-catalog-grid {
                grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
            }
        }
        
        /* Adaptación responsiva para Tablets */
        @media (max-width: 768px) {
            .ap-catalog-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
                gap: 1rem;
            }
        }
        
        /* Adaptación responsiva para Teléfonos Móviles */
        @media (max-width: 480px) {
            .ap-catalog-grid {
                grid-template-columns: repeat(1, minmax(0, 1fr)) !important;
            }
        }
    </style>

    
    <div class="ap-breadcrumb-container">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [['label' => 'Productos']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Productos']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
    </div>

    
    <div class="ap-catalog-layout">

        
        <aside class="ap-sidebar">
            <h3 class="ap-sidebar__title">Filtros</h3>

            <form method="GET" action="<?php echo e(route('shop.index')); ?>">

                
                <div class="ap-sidebar__section">
                    <h4 class="ap-sidebar__section-title">Categorías</h4>
                    <ul style="list-style: none; padding: 0; display: flex; flex-direction: column; gap: 6px;">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <label class="ap-sidebar__label">
                                    <input type="radio" name="category" value="<?php echo e($category->id); ?>"
                                           class="ap-sidebar__radio"
                                           <?php echo e(request('category') == $category->id ? 'checked' : ''); ?>

                                           onchange="this.form.submit()">
                                    <span><?php echo e($category->name); ?></span>
                                </label>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                
                <div class="ap-sidebar__section">
                    <h4 class="ap-sidebar__section-title">Marcas</h4>
                    <ul style="list-style: none; padding: 0; display: flex; flex-direction: column; gap: 6px;">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <label class="ap-sidebar__label">
                                    <input type="checkbox" name="brands[]" value="<?php echo e($brand->id); ?>"
                                           class="ap-sidebar__checkbox"
                                           <?php echo e(in_array($brand->id, (array)request('brands')) ? 'checked' : ''); ?>

                                           onchange="this.form.submit()">
                                    <span><?php echo e($brand->name); ?></span>
                                </label>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                
                <div class="ap-sidebar__section">
                    <h4 class="ap-sidebar__section-title">Precio</h4>
                    <div class="ap-sidebar__price-inputs">
                        <div class="ap-sidebar__price-field">
                            <span class="ap-sidebar__price-symbol">$</span>
                            <input type="number" name="min_price" placeholder="Mín" 
                                   value="<?php echo e(request('min_price')); ?>" class="ap-sidebar__input">
                        </div>
                        <span style="color: var(--text-muted); font-size: 13px;">–</span>
                        <div class="ap-sidebar__price-field">
                            <span class="ap-sidebar__price-symbol">$</span>
                            <input type="number" name="max_price" placeholder="Máx" 
                                   value="<?php echo e(request('max_price')); ?>" class="ap-sidebar__input">
                        </div>
                    </div>
                    <button type="submit" class="ap-sidebar__btn-submit">Filtrar precio</button>
                </div>

                
                <?php if(request()->anyFilled(['category', 'brands', 'min_price', 'max_price'])): ?>
                    <a href="<?php echo e(route('shop.index')); ?>" class="ap-sidebar__btn-clear">
                        Limpiar filtros
                    </a>
                <?php endif; ?>

            </form>
        </aside>

        
        <main class="ap-catalog-main">

            <div class="ap-catalog__header">
                <span class="ap-catalog__count">
                    Mostrando <?php echo e($products->count()); ?> de <?php echo e($products->total()); ?> repuestos encontrados
                </span>
            </div>

            
            <div id="products-wrapper" class="ap-catalog-grid">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="ap-catalog__empty" style="grid-column: 1 / -1;">
                        <div class="ap-catalog__empty-icon">🔍</div>
                        <h4 class="ap-catalog__empty-title">No encontramos resultados</h4>
                        <p class="ap-catalog__empty-text">Prueba cambiando los filtros seleccionados o la palabra clave.</p>
                    </div>
                <?php endif; ?>
            </div>

            
            <?php if($products->hasMorePages()): ?>
                <div id="infinite-scroll-trigger" class="ap-infinite-trigger" data-next-page="<?php echo e($products->nextPageUrl()); ?>">
                    <div id="infinite-scroll-spinner" class="ap-spinner-wheel hidden"></div>
                </div>
            <?php endif; ?>

        </main>

    </div>

    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const trigger = document.getElementById('infinite-scroll-trigger');
            const spinner = document.getElementById('infinite-scroll-spinner');
            const wrapper = document.getElementById('products-wrapper');

            if (!trigger) return;

            let nextPageUrl = trigger.getAttribute('data-next-page');
            let isLoading = false;

            const observer = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && nextPageUrl && !isLoading) {
                    loadMoreProducts();
                }
            }, {
                rootMargin: '150px'
            });

            observer.observe(trigger);

            function loadMoreProducts() {
                isLoading = true;
                spinner.classList.remove('hidden');

                fetch(nextPageUrl, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                .then(response => response.json())
                .then(data => {
                    wrapper.insertAdjacentHTML('beforeend', data.html);
                    nextPageUrl = data.nextPageUrl;
                    
                    if (!nextPageUrl) {
                        observer.disconnect();
                        trigger.remove();
                    }
                    
                    isLoading = false;
                    spinner.classList.add('hidden');
                })
                .catch(error => {
                    console.error('Error al cargar más productos:', error);
                    isLoading = false;
                    spinner.classList.add('hidden');
                });
            }
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $attributes = $__attributesOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__attributesOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $component = $__componentOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__componentOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\store\resources\views/shop/index.blade.php ENDPATH**/ ?>