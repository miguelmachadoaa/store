<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800">Piedras y Minerales</h2>
            <a href="<?php echo e(route('admin.stones.create')); ?>"
               class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Nueva Piedra</a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12 max-w-7xl mx-auto sm:px-6 lg:px-8">

        <div class="bg-white shadow-lg rounded-lg p-6 border">

            <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 text-green-700 px-4 py-2 rounded">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Imagen</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nombre</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subtítulo</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Orden</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Acciones</th>
                    </tr>
                </thead>

                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $stones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-6 py-4">
                                <?php if($stone->image): ?>
                                    <img src="<?php echo e(Storage::disk('r2')->url($stone->image)); ?>" alt="<?php echo e($stone->name); ?>" class="h-12 w-12 object-cover rounded-full border">
                                <?php else: ?>
                                    <div class="h-12 w-12 rounded-full bg-gray-100 border flex items-center justify-center text-xs text-gray-400">Sin img</div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 font-semibold text-gray-800"><?php echo e($stone->name); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($stone->subtitle ?? '-'); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($stone->sort_order); ?></td>
                            <td class="px-6 py-4">
                                <?php if($stone->is_active): ?>
                                    <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs">Activa</span>
                                <?php else: ?>
                                    <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-xs">Inactiva</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-right flex justify-end items-center gap-3">
                                <a href="<?php echo e(route('admin.stones.edit', $stone)); ?>"
                                   class="text-indigo-600 hover:text-indigo-900">Editar</a>

                                <form action="<?php echo e(route('admin.stones.destroy', $stone)); ?>" method="POST"
                                      onsubmit="return confirm('¿Eliminar piedra?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="text-red-600 hover:text-red-900">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-4 text-center text-gray-500">No hay piedras registradas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="mt-4">
                <?php echo e($stones->links()); ?>

            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\store\resources\views/admin/stones/index.blade.php ENDPATH**/ ?>