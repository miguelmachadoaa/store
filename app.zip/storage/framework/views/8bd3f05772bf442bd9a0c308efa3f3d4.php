<?php if (isset($component)) { $__componentOriginal9d41032d5dde91ab243771384dacb5df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d41032d5dde91ab243771384dacb5df = $attributes; } ?>
<?php $component = App\View\Components\FrontLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>



<style>
@import url('https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;600;700&family=Orbitron:wght@700;800&family=DM+Sans:wght@400;500;600;700&display=swap');

/* ── Variables Reutilizadas del Brandbook Global ──────────────── */
:root {
    --bg:            #FFFFFF;
    --bg-soft:       #F4F6F6;
    --navy:          #131921;
    --navy-light:    #1A2536;
    --orange:        #FFC933;
    --orange-hover:  #F3A847;
    --black:         #0F1111;
    --border:        #D5D9D9;
    --muted:         #555555;
    --link:          #007185;
    --green:         #007600;
    --green-bg:      #EAF7EA;
    --green-border:  #B5D9B5;
    --yellow:        #B12704; /* Manteniendo coherencia con precios y alertas cálidas */
    --yellow-bg:     #FFF8EC;
    --yellow-border: #F5DDA0;
    --radius:        4px;
    --shadow:        0 1px 4px rgba(0,0,0,.07), 0 2px 14px rgba(0,0,0,.05);
    --font-display:  'Orbitron', sans-serif;
    --font-tech:     'Chakra Petch', sans-serif;
    --font-body:     'DM Sans', sans-serif;
}

/* ── Estructura de la Página ────────────────────────────────── */
.zst-page {
    background: var(--bg-soft);
    min-height: 80vh;
    padding: 40px 0 70px;
    font-family: var(--font-body);
    color: var(--black);
}
.zst-wrap {
    width: 100%;
    max-width: 680px;
    margin: 0 auto;
    padding: 0 16px;
}

/* ── Contenedor Panel Principal ──────────────────────────────── */
.zst-panel {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
}

/* Encabezado del Panel */
.zst-panel__hd {
    background: var(--navy);
    padding: 14px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
}
.zst-panel__hd-title {
    font-family: var(--font-display);
    font-size: 11px;
    font-weight: 700;
    color: #fff;
    text-transform: uppercase;
    letter-spacing: .8px;
    margin: 0;
}

/* ── Badges Dinámicos de Estado (Estilo Técnico) ─────────────── */
.zst-badge {
    font-family: var(--font-tech);
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .8px;
    padding: 3px 10px;
    border-radius: 2px;
}
.zst-badge--pending {
    background: var(--orange);
    color: var(--black);
    border: 1px solid #A88734;
}
.zst-badge--success {
    background: var(--green-bg);
    color: var(--green);
    border: 1px solid var(--green-border);
}

/* Cuerpo del Panel */
.zst-panel__bd { padding: 24px 20px; }

/* Meta Datos del Cliente */
.zst-meta-group { margin-bottom: 20px; }
.zst-meta-row {
    font-size: 13px;
    line-height: 1.5;
    margin-bottom: 6px;
    color: var(--muted);
}
.zst-meta-row strong { color: var(--black); font-weight: 600; }

/* ── Subtítulos de Secciones Internas ─────────────────────────── */
.zst-subhd {
    font-family: var(--font-display);
    font-size: 10px;
    font-weight: 700;
    color: var(--navy);
    text-transform: uppercase;
    letter-spacing: .5px;
    border-b: 1px solid var(--border);
    padding-bottom: 6px;
    margin: 24px 0 10px;
}

/* ── Lista de Productos ───────────────────────────────────────── */
.zst-items { list-style: none; margin: 0; padding: 0; }
.zst-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid #F3F3F3;
    font-size: 13px;
}
.zst-item:last-child { border-bottom: none; }
.zst-item__name { color: var(--black); font-weight: 500; }
.zst-item__price { font-weight: 600; color: var(--black); }

/* ── Sección de Totales Finales ───────────────────────────────── */
.zst-summary {
    margin-top: 20px;
    padding-top: 16px;
    border-top: 2px solid var(--navy);
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
}
.zst-summary__label {
    font-family: var(--font-display);
    font-size: 11px;
    font-weight: 700;
    color: var(--navy);
    text-transform: uppercase;
    letter-spacing: .5px;
}
.zst-summary__amounts { text-align: right; }
.zst-summary__usd {
    font-family: var(--font-display);
    font-size: 22px;
    font-weight: 800;
    color: var(--navy);
    line-height: 1;
}
.zst-summary__bs {
    font-family: var(--font-tech);
    font-size: 12px;
    color: var(--link);
    font-weight: 700;
    margin-top: 4px;
}

/* ── Alertas de Sistema (Flash Sessions) ─────────────────────── */
.zst-alert {
    display: flex;
    align-items: center;
    background: var(--green-bg);
    border: 1px solid var(--green-border);
    border-radius: var(--radius);
    padding: 12px 16px;
    margin-bottom: 16px;
    font-size: 13px;
    color: var(--green);
}

/* ── Acciones de Botón ────────────────────────────────────────── */
.zst-action-box {
    margin-top: 24px;
    padding-top: 20px;
    border-top: 1px solid var(--border);
}
.zst-btn-action {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    background: var(--orange);
    border: 1px solid #A88734;
    color: var(--black);
    font-family: var(--font-tech);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .5px;
    padding: 12px 16px;
    border-radius: var(--radius);
    text-decoration: none;
    transition: background .15s;
    cursor: pointer;
    width: 100%;
    text-align: center;
    box-shadow: 0 1px 2px rgba(0,0,0,0.05);
}
.zst-btn-action:hover { background: var(--orange-hover); }
</style>

<div class="zst-page">
    <div class="zst-wrap">

        <div class="zst-panel">
            
            <div class="zst-panel__hd">
                <h2 class="zst-panel__hd-title">Estado del Pedido</h2>
                
                
                <?php if($order->status === 'pendiente' || $order->status === 'pending'): ?>
                    <span class="zst-badge zst-badge--pending">Pendiente</span>
                <?php else: ?>
                    <span class="zst-badge zst-badge--success"><?php echo e($order->status); ?></span>
                <?php endif; ?>
            </div>

            <div class="zst-panel__bd">
                
                <?php if(session('success')): ?>
                    <div class="zst-alert">
                        <span>✓ <?php echo e(session('success')); ?></span>
                    </div>
                <?php endif; ?>

                
                <div class="zst-meta-group">
                    <div class="zst-meta-row"><strong>Cliente:</strong> <?php echo e($order->customer_name); ?></div>
                    <div class="zst-meta-row"><strong>Dirección de Entrega:</strong> <?php echo e($order->address); ?></div>
                </div>

                
                <div class="zst-subhd">Artículos Solicitados</div>
                <ul class="zst-items">
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="zst-item">
                            <span class="zst-item__name"><?php echo e($item->name); ?> (x<?php echo e($item->quantity); ?>)</span>
                            <span class="zst-item__price">$<?php echo e(number_format($item->price * $item->quantity, 2)); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                
                <div class="zst-summary">
                    <span class="zst-summary__label">Total del Pedido</span>
                    <div class="zst-summary__amounts">
                        <div class="zst-summary__usd">$<?php echo e(number_format($order->total, 2)); ?></div>
                        <div class="zst-summary__bs">Ref. Bs: Bs. <?php echo e(number_format($order->total_bs, 2)); ?></div>
                    </div>
                </div>

                
                <?php if($order->status === 'pendiente' || $order->status === 'pending'): ?>
                    <div class="zst-action-box">
                        <a href="<?php echo e(URL::signedRoute('guest.payments.report', ['orderId' => $order->id])); ?>" class="zst-btn-action">
                            <span>💳 Reportar Pago para este Pedido</span>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $attributes = $__attributesOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__attributesOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $component = $__componentOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__componentOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\store\resources\views/checkout/view_guest_order.blade.php ENDPATH**/ ?>