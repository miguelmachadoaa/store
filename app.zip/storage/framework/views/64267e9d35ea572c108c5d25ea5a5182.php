<?php if (isset($component)) { $__componentOriginal9d41032d5dde91ab243771384dacb5df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d41032d5dde91ab243771384dacb5df = $attributes; } ?>
<?php $component = App\View\Components\FrontLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', $product->meta_title ?: $product->name . ' - ' . config('app.name')); ?>
    <?php $__env->startSection('meta_description', $product->meta_description ?: Str::limit(strip_tags($product->description), 160)); ?>

    <div class="ap-breadcrumb-container">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['items' => [
            ['label' => 'Productos', 'url' => route('shop.index')],
            ['label' => $product->category->name ?? 'Sin Categoría', 'url' => $product->category ? route('shop.byCategory', $product->category->slug) : null],
            ['label' => $product->name]
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['label' => 'Productos', 'url' => route('shop.index')],
            ['label' => $product->category->name ?? 'Sin Categoría', 'url' => $product->category ? route('shop.byCategory', $product->category->slug) : null],
            ['label' => $product->name]
        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
    </div>

    
    <div class="ap-detail-layout">

        
        <div>
            <div class="ap-gallery__main-wrapper"
                x-data="{ zoom: false, x: 0, y: 0 }"
                @mousemove="x = ($event.offsetX / $event.target.offsetWidth) * 100; y = ($event.offsetY / $event.target.offsetHeight) * 100"
                @mouseenter="zoom = true" @mouseleave="zoom = false">

                <img id="main-image" src="<?php echo e(asset('storage/' . $product->image)); ?>"
                    class="ap-gallery__main"
                    :style="zoom ? `transform: scale(2); transform-origin: ${x}% ${y}%;` : ''"
                    alt="<?php echo e($product->name); ?>">
            </div>

            <?php if($product->images && count($product->images) > 0): ?>
                <div class="thumb-slider-container">
                    <div class="swiper thumbSwiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="thumb-item active" onclick="changeMainImage('<?php echo e(asset('storage/' . $product->image)); ?>', this)">
                                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="Principal">
                                </div>
                            </div>
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additionalImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="thumb-item" onclick="changeMainImage('<?php echo e(asset('storage/' . $additionalImage)); ?>', this)">
                                        <img src="<?php echo e(asset('storage/' . $additionalImage)); ?>" alt="Adicional">
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="ap-info-panel">
            <span class="section-eyebrow"><?php echo e($product->brand->name ?? 'Genérico'); ?></span>
            <h1><?php echo e($product->name); ?></h1>
            
            <div class="ap-info-meta">
                Categoría: <?php if($product->category): ?> <a href="<?php echo e(route('shop.byCategory', $product->category->slug)); ?>"><?php echo e($product->category->name); ?></a> <?php else: ?> Sin Categoría <?php endif; ?>
            </div>

            
            <div class="ap-info-price-card">
                <?php
                    // Reemplazamos la función inexistente setting() por el sistema nativo config() de Laravel.
                    // Si no existen en tu config, por defecto se asumirá true para mostrar ambos.
                    $showUsd = config('shop.mostrar_precio_usd', true);
                    $showBs = config('shop.mostrar_precio_bs', true);
                ?>

                <?php if($product->hasDiscount()): ?>
                    <div class="ap-info-price-primary has-discount">
                        <?php if($showUsd): ?> $<?php echo e(number_format($product->price, 2)); ?> <?php endif; ?>
                        <span style="font-size: 14px; text-decoration: line-through; color: #888; margin-left: 10px;">
                            $<?php echo e(number_format($product->compare_price, 2)); ?>

                        </span>
                        <span style="font-size: 14px; color: #B12704; font-weight: bold; margin-left: 8px;">
                            −<?php echo e($product->discount_percentage); ?>%
                        </span>
                    </div>
                    <?php if($showBs): ?>
                        <div class="ap-info-price-secondary">
                            Bs. <?php echo e(number_format($product->price_bs, 2)); ?>

                            <span style="text-decoration: line-through; margin-left: 6px; font-size: 12px;">
                                Bs. <?php echo e(number_format($product->compare_price_bs, 2)); ?>

                            </span>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="ap-info-price-primary">
                        <?php if($showUsd): ?> $<?php echo e(number_format($product->price, 2)); ?> <?php endif; ?>
                    </div>
                    <?php if($showBs): ?>
                        <div class="ap-info-price-secondary">
                            Bs. <?php echo e(number_format($product->price_bs, 2)); ?>

                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <div class="ap-info-desc">
                <h3 class="ap-sidebar__section-title" style="margin-bottom: 8px;">Descripción del Repuesto</h3>
                <?php echo $product->description; ?>

            </div>

            <div style="max-width: 300px; margin-top: 20px;">
                <?php if (isset($component)) { $__componentOriginal0ebc6ef07b571ddf6bdd9d88111343c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ebc6ef07b571ddf6bdd9d88111343c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.add-to-cart-button','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('add-to-cart-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ebc6ef07b571ddf6bdd9d88111343c0)): ?>
<?php $attributes = $__attributesOriginal0ebc6ef07b571ddf6bdd9d88111343c0; ?>
<?php unset($__attributesOriginal0ebc6ef07b571ddf6bdd9d88111343c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ebc6ef07b571ddf6bdd9d88111343c0)): ?>
<?php $component = $__componentOriginal0ebc6ef07b571ddf6bdd9d88111343c0; ?>
<?php unset($__componentOriginal0ebc6ef07b571ddf6bdd9d88111343c0); ?>
<?php endif; ?>
            </div>
        </div>

    </div>

    
    <div class="ap-reviews-section">
        <div class="ap-reviews-layout">
            
            
            <div class="ap-review-form-card">
                <h3>Escribe una reseña</h3>
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('products.reviews.store', $product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="ap-form-group">
                            <label for="rating">Calificación</label>
                            <select name="rating" id="rating" class="ap-form-control" required>
                                <option value="5">★★★★★ (5/5)</option>
                                <option value="4">★★★★☆ (4/5)</option>
                                <option value="3">★★★☆☆ (3/5)</option>
                                <option value="2">★★☆☆☆ (2/5)</option>
                                <option value="1">★☆☆☆☆ (1/5)</option>
                            </select>
                        </div>
                        <div class="ap-form-group">
                            <label for="comment">Tu Comentario</label>
                            <textarea name="comment" id="comment" rows="4" class="ap-form-control" placeholder="¿Qué te pareció la calidad de esta pieza?" required></textarea>
                        </div>
                        <button type="submit" class="ap-sidebar__btn-submit" style="padding: 11px 0;">Enviar Opinión</button>
                    </form>
                <?php else: ?>
                    <p style="font-size: 13px; color: var(--text-muted);">
                        Debes <a href="<?php echo e(route('login')); ?>" style="color:var(--text-link); font-weight:bold;">iniciar sesión</a> para calificar este producto.
                    </p>
                <?php endif; ?>
            </div>

            
            <div class="ap-reviews-list">
                <h3>Opiniones de Compradores</h3>
                <div style="display: flex; flex-direction: column;">
                    <?php $__empty_1 = true; $__currentLoopData = $product->reviews()->where('is_approved', true)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="ap-review-row">
                            <div class="ap-review-row__meta">
                                <?php echo e($review->user->name); ?>

                                <span class="ap-review-row__date"><?php echo e($review->created_at->format('d/m/Y')); ?></span>
                            </div>
                            <div class="ap-review-row__stars">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <?php if($i <= $review->rating): ?> ★ <?php else: ?> ☆ <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                            <p class="ap-review-row__text"><?php echo e($review->comment); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="ap-catalog__empty" style="padding: 30px 20px;">
                            <p class="ap-catalog__empty-text">Este repuesto aún no tiene reseñas. ¡Sé el primero en aportar!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            if(typeof Swiper !== 'undefined') {
                new Swiper(".thumbSwiper", {
                    slidesPerView: 4,
                    spaceBetween: 10,
                    breakpoints: {
                        480: { slidesPerView: 4 },
                        1024: { slidesPerView: 5 },
                    }
                });
            }
        });

        function changeMainImage(src, el) {
            const mainImg = document.getElementById('main-image');
            if(mainImg) mainImg.src = src;

            document.querySelectorAll('.thumb-item').forEach(img => {
                img.classList.remove('active');
            });
            el.classList.add('active');
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $attributes = $__attributesOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__attributesOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $component = $__componentOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__componentOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\store\resources\views/shop/detail.blade.php ENDPATH**/ ?>