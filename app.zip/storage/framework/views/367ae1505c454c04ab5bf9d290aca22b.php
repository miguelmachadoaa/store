<article class="ap-card">

    
    <a href="<?php echo e(route('product.detail', $product->slug)); ?>" class="ap-card__img-wrap">
        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" loading="lazy">

        <?php if($product->hasDiscount()): ?>
            <span class="ap-card__badge">−<?php echo e($product->discount_percentage); ?>%</span>
        <?php endif; ?>
    </a>

    
    <?php if(auth()->guard()->check()): ?>
        <button onclick="toggleWishlist(<?php echo e($product->id); ?>, this)"
            class="ap-card__wishlist <?php echo e($product->isFavoritedBy(auth()->user()) ? 'is-wishlisted' : ''); ?>"
            data-id="<?php echo e($product->id); ?>"
            aria-label="Agregar a favoritos">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
        </button>
    <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="ap-card__wishlist" title="Inicia sesión para guardar" aria-label="Guardar en favoritos">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
        </a>
    <?php endif; ?>

    
    <div class="ap-card__body">

        <?php if(isset($product->category)): ?>
            <p class="ap-card__tag"><?php echo e($product->category->name); ?></p>
        <?php endif; ?>

        <a href="<?php echo e(route('product.detail', $product->slug)); ?>" class="ap-card__name">
            <?php echo e($product->name); ?>

        </a>

        
        <?php
            $showUsd = $storeSettings->showUsd();
            $showBs  = $storeSettings->showBs();
        ?>

        <div class="ap-card__price-block">
            <?php if($product->hasDiscount()): ?>
                <div class="ap-card__price-row-primary">
                    <span class="ap-card__price-main is-discounted">
                        <?php if($showUsd): ?> $<?php echo e(number_format($product->price, 2)); ?> <?php endif; ?>
                    </span>
                    <span class="ap-card__price-old">
                        <?php if($showUsd): ?> $<?php echo e(number_format($product->compare_price, 2)); ?> <?php endif; ?>
                    </span>
                    <span class="ap-card__price-pct">−<?php echo e($product->discount_percentage); ?>%</span>
                </div>
                
                <?php if($showBs): ?>
                    <div class="ap-card__price-row-secondary">
                        <span class="ap-card__price-bs">Bs. <?php echo e(number_format($product->price_bs, 2)); ?></span>
                        <span class="ap-card__price-bs-old">Bs. <?php echo e(number_format($product->compare_price_bs, 2)); ?></span>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="ap-card__price-row-primary">
                    <span class="ap-card__price-main">
                        <?php if($showUsd): ?> $<?php echo e(number_format($product->price, 2)); ?> <?php endif; ?>
                    </span>
                </div>
                <?php if($showBs): ?>
                    <div class="ap-card__price-row-secondary">
                        <span class="ap-card__price-bs">Bs. <?php echo e(number_format($product->price_bs, 2)); ?></span>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="ap-card__sep"></div>

        <div class="ap-card__actions">
            <?php if (isset($component)) { $__componentOriginal0ebc6ef07b571ddf6bdd9d88111343c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ebc6ef07b571ddf6bdd9d88111343c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.add-to-cart-button','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('add-to-cart-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ebc6ef07b571ddf6bdd9d88111343c0)): ?>
<?php $attributes = $__attributesOriginal0ebc6ef07b571ddf6bdd9d88111343c0; ?>
<?php unset($__attributesOriginal0ebc6ef07b571ddf6bdd9d88111343c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ebc6ef07b571ddf6bdd9d88111343c0)): ?>
<?php $component = $__componentOriginal0ebc6ef07b571ddf6bdd9d88111343c0; ?>
<?php unset($__componentOriginal0ebc6ef07b571ddf6bdd9d88111343c0); ?>
<?php endif; ?>
        </div>

    </div>
</article><?php /**PATH C:\laragon\www\store\resources\views/components/product-card.blade.php ENDPATH**/ ?>