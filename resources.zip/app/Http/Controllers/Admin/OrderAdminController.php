<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderAdminController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $date = $request->input('date');

        $orders = Order::latest()
            ->when($search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('customer_name', 'like', "%{$search}%")
                    ->orWhere('customer_rif', 'like', "%{$search}%") // Usando tu columna real
                    ->orWhere('total', 'like', "%{$search}%")
                    ->orWhere('total_bs', 'like', "%{$search}%");
                });
            })
            ->when($date, function ($query, $date) {
                $query->whereDate('created_at', $date);
            })
            ->paginate(10)
            ->appends($request->all()); 

        return view('admin.orders.index', compact('orders'));
    }

    public function show(Order $order)
    {
        $order->load(['items', 'paymentReports']);
        return view('admin.orders.show', compact('order'));
    }

    public function updateStatus(Request $request, Order $order)
    {
        $request->validate([
            'status' => 'required|in:pendiente,pagada,enviada,cancelada'
        ]);

        $order->update([
            'status' => $request->status
        ]);

        return redirect()->back()->with('success', 'Estado actualizado correctamente.');
    }
}