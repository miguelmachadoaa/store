<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PaymentReport; // Recuerda crear este modelo si no lo tienes
use Illuminate\Http\Request;

class PaymentReportAdminController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');

        $reports = PaymentReport::with(['user', 'order'])
            ->latest()
            ->when($search, function ($query, $search) {
                $query->where('reference_number', 'like', "%{$search}%")
                      ->orWhere('bank_name', 'like', "%{$search}%")
                      ->orWhereHas('order', function($q) use ($search) {
                          $q->where('customer_name', 'like', "%{$search}%");
                      });
            })
            ->paginate(15)
            ->appends($request->all());

        return view('admin.payments.index', compact('reports'));
    }

    public function updateStatus(Request $request, PaymentReport $report)
    {
        $request->validate([
            'status' => 'required|in:approved,rejected,pending'
        ]);

        $report->update(['status' => $request->status]);

        // Opcional: Si apruebas el pago, podrías cambiar automáticamente el estado de la orden a 'pagada'
        if ($request->status === 'approved') {
            $report->order->update(['status' => 'pagada']);
        }

        return redirect()->back()->with('success', 'Estado del pago actualizado.');
    }
}